function execute() {
    return Response.success([
        {title: "最近更新小说列表", input: "", script: "gen.js"}, 
    ]);
}