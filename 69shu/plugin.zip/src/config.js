
let BASE_URL = 'https://69shu.biz';
  var host = BASE_URL;
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}