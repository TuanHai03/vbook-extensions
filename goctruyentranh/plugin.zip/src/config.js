let BASE_URL="https://goctruyentranh.net";

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
    
} catch (error) {
}